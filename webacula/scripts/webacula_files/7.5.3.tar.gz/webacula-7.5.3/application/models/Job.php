<?php
/**
 * Copyright 2007, 2008, 2009, 2010, 2011, 2012 Yuriy Timofeev tim4dev@gmail.com
 *
 * Webacula is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Webacula is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Webacula.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @author Yuriy Timofeev <tim4dev@gmail.com>
 * @package webacula
 * @license http://www.gnu.org/licenses/gpl-3.0.html GNU Public License
 *
 */

class Job extends Zend_Db_Table
{
    const BEGIN_LIST = '/^======.*/'; // a sign of the beginning of the list (not always)
    const END_LIST   = '/^====$/';   // a sign of the end of the list (always present)

    const RUNNING_JOBS    = '/Running Jobs:/';        // top of the list of running jobs
    const NO_JOBS_RUNNING =  '/No Jobs running\./';   // no running jobs

    const SCHEDULED_JOBS    = '/Scheduled Jobs:/';     // top of the list of scheduled tasks
    const NO_SCHEDULED_JOBS = '/No Scheduled Jobs\./';  // No scheduled tasks

    const EMPTY_RESULT = 'EMPTY_RESULT';     // if nothing found

    public $db;
    public $db_adapter;
    protected $bacula_acl; // bacula acl



    public function __construct($config = array())
    {
        $this->db         = Zend_Registry::get('db_bacula');
        $this->db_adapter = Zend_Registry::get('DB_ADAPTER');
        $this->bacula_acl = new MyClass_BaculaAcl();
        parent::__construct($config);
    }

    
    protected function _setupTableName()
    {
        switch ($this->db_adapter) {
        case 'PDO_PGSQL':
            $this->_name = 'job';
            break;
        default: // including mysql, sqlite
            $this->_name = 'Job';
        }
        parent::_setupTableName();
    }


    
    protected function _setupPrimaryKey()
    {
        $this->_primary = 'jobid';
        parent::_setupPrimaryKey();
    }


    
	/**
	 * If there JobId exist in the database Bacula ...
	 *
	 * @return TRUE if exist
	 * @param integer $jobid
	 */
	function isJobIdExists($jobid)
	{
   		$select = new Zend_Db_Select($this->db);
    	$select->from('Job', array('JobId', 'Name'));
    	$select->where("JobId = ?", $jobid);
    	$select->limit(1);
        $stmt = $select->query();
        // do Bacula ACLs
        $res = $this->bacula_acl->doBaculaAcl( $stmt->fetchAll(), 'name', 'job');
        return ( empty ($res) ) ? FALSE : TRUE;
	}

    
        /**
	 * If there Job Name exist in the database Bacula ...
	 *
	 * @return TRUE if exist
	 * @param string $jobname
	 */
	function isJobNameExists($jobname)
	{
   		$select = new Zend_Db_Select($this->db);
    	$select->from('Job', array('Name'));
    	$select->where("Name = ?", $jobname);
    	$select->limit(1);
        $stmt = $select->query();
        // do Bacula ACLs
        $res = $this->bacula_acl->doBaculaAcl( $stmt->fetchAll(), 'name', 'job');
        return ( empty ($res) ) ? FALSE : TRUE;
	}


	/**
	 * Get data about last terminated Jobs (executed in last 24 hours)
	 * See also http://www.bacula.org/manuals/en/developers/developers/Database_Tables.html
	 *
	 */
        function getTerminatedJobs($days, $orderp=null)
        {
        if ( empty($days) ) 
             $days = 1;
        $select = new Zend_Db_Select($this->db);
        //$select->distinct();
        $last1day = date('Y-m-d H:i:s', time() - ($days * 86400)); // for compatibility with older versions of mysql: NOW() - INTERVAL $days

        switch ($this->db_adapter) {
        	case 'PDO_MYSQL':
                $select->from(array('j' => 'Job'),
                    array('JobId', 'JobName' => 'Name', 'Level', 'ClientId',
                    'StartTime', 'EndTime',
                    'VolSessionId', 'VolSessionTime', 'JobFiles', 'JobBytes', 'JobErrors', 'PoolId',
                    'FileSetId', 'PurgedFiles', 'JobStatus', 'Type',
                    'DurationTime' => 'TIMEDIFF(EndTime, StartTime)',
                    'Reviewed'
                ));
                $select->joinLeft(array('s' => 'Status'), 'j.JobStatus = s.JobStatus', array('JobStatusLong'=>'JobStatusLong'));
        	break;
            case 'PDO_PGSQL':
                // PostgreSQL
                // http://www.postgresql.org/docs/8.0/static/functions-datetime.html
                $select->from(array('j' => 'Job'),
                    array('JobId', 'JobName' => 'Name', 'Level', 'ClientId',
                    'StartTime', 'EndTime',
                    'VolSessionId', 'VolSessionTime', 'JobFiles', 'JobBytes', 'JobErrors', 'PoolId',
                    'FileSetId', 'PurgedFiles', 'JobStatus', 'Type',
                    'DurationTime' => '(EndTime - StartTime)',
                    'Reviewed'
                ));
                $select->joinLeft(array('s' => 'Status'), 'j.JobStatus = s.JobStatus', array('JobStatusLong'=>'JobStatusLong'));
                break;
            case 'PDO_SQLITE':
                // SQLite3 Documentation
                // http://sqlite.org/lang_datefunc.html
                // bug http://framework.zend.com/issues/browse/ZF-884
                // http://sqlite.org/pragma.html
                //$res = $db->query('PRAGMA short_column_names=1'); // not affected
                //$res = $db->query('PRAGMA full_column_names=0'); // not affected
                $select->from(array('j' => 'Job'),
                    array('jobid'=>'JobId', 'JobName' => 'Name', 'level'=>'Level', 'clientid'=>'ClientId',
                    'starttime'=>'StartTime', 'endtime'=>'EndTime',
                    'volsessionid'=>'VolSessionId', 'volsessiontime'=>'VolSessionTime', 'jobfiles'=>'JobFiles',
                    'jobbytes'=>'JobBytes', 'joberrors'=>'JobErrors', 'poolid'=>'PoolId',
                    'filesetid'=>'FileSetId', 'purgedfiles'=>'PurgedFiles', 'jobstatus'=>'JobStatus',
                                'type' => 'Type',
                    'DurationTime' => "(strftime('%H:%M:%S',strftime('%s',EndTime) - strftime('%s',StartTime),'unixepoch'))",
                    'reviewed'=>'Reviewed'
                ));
                $select->joinLeft(array('s' => 'Status'), 'j.JobStatus = s.JobStatus', array('jobstatuslong' => 'JobStatusLong'));
                break;
        }
        $select->joinLeft(array('c' => 'Client'), 'j.ClientId = c.ClientId', array('ClientName' => 'Name'));
        $select->joinLeft(array('p' => 'Pool'),	'j.PoolId = p.PoolId', array('PoolName' => 'Name'));
        $select->joinLeft(array('f' => 'FileSet'), 'j.FileSetId = f.FileSetId');
        $select->joinLeft(array('sd'=> 'webacula_jobdesc'), 'j.Name = sd.name_job');
        $select->joinLeft(array('wjs'=> 'webacula_job_size'), 'j.JobId = wjs.JobId', array('FileSize' => 'FileSize'));
        /*
         * developers/Database_Tables.html
C   Created but not yet running
R   Running
B   Blocked
T   Terminated normally
W   Terminated normally with warnings
E   Terminated in Error
e   Non-fatal error
f   Fatal error
D   Verify Differences
A   Canceled by the user
I   Incomplete Job
F   Waiting on the File daemon
S   Waiting on the Storage daemon
m   Waiting for a new Volume to be mounted
M   Waiting for a Mount
s   Waiting for Storage resource
j   Waiting for Job resource
c   Waiting for Client resource
d   Wating for Maximum jobs
t   Waiting for Start Time
p   Waiting for higher priority job to finish
i   Doing batch insert file records
a   SD despooling attributes
l   Doing data despooling
L   Committing data (last despool)
         */
        $select->where("j.JobStatus IN ('T', 'E', 'e', 'f', 'A', 'W', 'D')");
        $select->where("j.EndTime > ?", $last1day);
        if ( empty($orderp) ) {
	   $order = array('StartTime', 'JobId');
        } else {
           $order = $orderp;
        }
        $select->order($order);
        //$sql = $select->__toString(); echo "<pre>$sql</pre>"; exit; // for !!!debug!!!
        $stmt = $select->query();
        // do Bacula ACLs
        return $this->bacula_acl->doBaculaAcl( $stmt->fetchAll(), 'jobname', 'job');
    }

    

    /**
     * Get data about running Jobs
     * from DB Catalog
     */
    function getRunningJobs()
    {
    	$select = new Zend_Db_Select($this->db);
    	$select->distinct();
        /*
         * developers/Database_Tables.html
C   Created but not yet running
R   Running
B   Blocked
T   Terminated normally
W   Terminated normally with warnings
E   Terminated in Error
e   Non-fatal error
f   Fatal error
D   Verify Differences
A   Canceled by the user
I   Incomplete Job
F   Waiting on the File daemon
S   Waiting on the Storage daemon
m   Waiting for a new Volume to be mounted
M   Waiting for a Mount
s   Waiting for Storage resource
j   Waiting for Job resource
c   Waiting for Client resource
d   Wating for Maximum jobs
t   Waiting for Start Time
p   Waiting for higher priority job to finish
i   Doing batch insert file records
a   SD despooling attributes
l   Doing data despooling
L   Committing data (last despool)
         */
        switch ($this->db_adapter) {
        case 'PDO_MYSQL':
        	$last7day = date('Y-m-d H:i:s', time() - 604800);
            $select->from(array('j' => 'Job'),
    		  array('JobId', 'JobName' => 'Name', 'Level', 'ClientId',
    		  'StartTime' => "j.StartTime", 'EndTime'   => "j.EndTime",
    		  'VolSessionId', 'VolSessionTime', 'JobFiles', 'JobBytes', 'JobErrors', 'Reviewed', 'PoolId',
        	   'FileSetId', 'PurgedFiles', 'JobStatus',
        	   'DurationTime' => 'TIMEDIFF(NOW(), StartTime)'
    		));
	    	$select->joinLeft(array('s' => 'Status'), 'j.JobStatus = s.JobStatus', array('JobStatusLong' => 'JobStatusLong'));
        	$select->joinLeft(array('c' => 'Client'), 'j.ClientId = c.ClientId', array('ClientName' => 'Name'));
	       	$select->joinLeft(array('p' => 'Pool'),	'j.PoolId = p.PoolId', array('PoolName' => 'Name'));
            $select->joinLeft(array('sd'=> 'webacula_jobdesc'), 'j.Name = sd.name_job');
    		$select->where("(j.EndTime = 0) OR (j.EndTime IS NULL) OR ".
                "(j.JobStatus IN ('C','R','B','e','F','S','m','M','s','j','c','d','t','p','i','a','l','L'))");
	        $select->where("j.StartTime > ?", $last7day);
			break;
    	case 'PDO_PGSQL':
            // PostgreSQL
            // http://www.postgresql.org/docs/8.0/static/functions-datetime.html
            $select->from(array('j' => 'Job'),
    		  array('JobId', 'JobName' => 'Name', 'Level', 'ClientId',
    		  'StartTime' => "j.StartTime", 'EndTime'   => "j.EndTime",
    		  'VolSessionId', 'VolSessionTime', 'JobFiles', 'JobBytes', 'JobErrors', 'Reviewed', 'PoolId',
        	   'FileSetId', 'PurgedFiles', 'JobStatus',
        	   'DurationTime' => '(NOW() - StartTime)'
    		));
	    	$select->joinLeft(array('s' => 'Status'), 'j.JobStatus = s.JobStatus', array('JobStatusLong' => 'JobStatusLong'));
        	$select->joinLeft(array('c' => 'Client'), 'j.ClientId = c.ClientId', array('ClientName' => 'Name'));
	       	$select->joinLeft(array('p' => 'Pool'),	'j.PoolId = p.PoolId', array('PoolName' => 'Name'));
            $select->joinLeft(array('sd'=> 'webacula_jobdesc'), 'j.Name = sd.name_job');
   			$select->where("(j.EndTime IS NULL) OR ".
                "(j.JobStatus IN ('C','R','B','e','F','S','m','M','s','j','c','d','t','p','i','a','l','L'))");
    		$select->where("j.StartTime > ( NOW() - INTERVAL '7 days' )");
            break;
		case 'PDO_SQLITE':
			// SQLite3 Documentation
			// http://sqlite.org/lang_datefunc.html
			// bug http://framework.zend.com/issues/browse/ZF-884
			// http://sqlite.org/pragma.html
			//$res = $db->query('PRAGMA short_column_names=1'); // not affected
			//$res = $db->query('PRAGMA full_column_names=0'); // not affected
			$select->from(array('j' => 'Job'),
				array('jobid'=>'JobId', 'JobName' => 'Name', 'level'=>'Level', 'clientid'=>'ClientId',
				'starttime' => "j.StartTime", 'endtime'   => "j.EndTime",
				'volsessionid'=>'VolSessionId', 'volsessiontime'=>'VolSessionTime', 'jobfiles'=>'JobFiles',
				'jobbytes'=>'JobBytes', 'joberrors'=>'JobErrors', 'reviewed' => 'Reviewed', 'poolid'=>'PoolId',
				'filesetid'=>'FileSetId', 'purgedfiles'=>'PurgedFiles', 'jobstatus'=>'JobStatus',
				'DurationTime' => "(strftime('%H:%M:%S',strftime('%s','now') - strftime('%s',StartTime),'unixepoch'))"
			));
			$select->joinLeft(array('s' => 'Status'), 'j.JobStatus = s.JobStatus', array('jobstatuslong' => 'JobStatusLong'));
			$select->joinLeft(array('c' => 'Client'), 'j.ClientId = c.ClientId', array('ClientName' => 'Name'));
			$select->joinLeft(array('p' => 'Pool'), 'j.PoolId = p.PoolId', array('PoolName' => 'Name'));
            $select->joinLeft(array('sd'=> 'webacula_jobdesc'), 'j.Name = sd.name_job');
			$select->where("(datetime(j.EndTime) IS NULL) OR ".
                "(j.JobStatus IN ('C','R','B','e','F','S','m','M','s','j','c','d','t','p','i','a','l','L'))");
			$select->where("j.StartTime > datetime('now','-7 days')");
			break;
        }
    	$select->order(array("StartTime", "JobId"));
    	//$sql = $select->__toString(); echo "<pre>$sql</pre>"; exit; // for !!!debug!!!
		$stmt = $select->query();
        // do Bacula ACLs
        return $this->bacula_acl->doBaculaAcl( $stmt->fetchAll(), 'jobname', 'job');
    }


    
    /**
	 * Running Jobs (from Director)
	 * For more information. Because Information from the Catalog database is not always correct.
     *
     * === Known bugs ===
     * 1. Running Jobs - instead of (delimiter m / d fields - space) :
     *          24 Increme  job.name.test.4  2010-11-08_21.56.48_39 running
     *      Bacula may issue (delimiter m / d fields - point) :
     *          24 Increme  job.name.test.4.2010-11-08_21.56.48_39 running
	 */
    function getDirRunningJobs()
    {
    	$config = Zend_Registry::get('config');

    	// check access to bconsole
    	if ( !file_exists($config->general->bacula->bconsole))	{
    		$aresult[] = 'NOFOUND';
    		return $aresult;
    	}

    	$bconsolecmd = '';
        if ( isset($config->general->bacula->sudo))	{
            // run with sudo
            $bconsolecmd = $config->general->bacula->sudo . ' ' . $config->general->bacula->bconsole . ' ' .
                    $config->general->bacula->bconsolecmd;
        } else {
            $bconsolecmd = $config->general->bacula->bconsole . ' ' . $config->general->bacula->bconsolecmd;
        }

    	// run bconsole
    	$command_output = '';
    	$return_var = 0;
    	exec($bconsolecmd . ' <<EOF
status director
quit
EOF', $command_output, $return_var);

    	//echo "<pre>"; print_r($command_output); echo "</pre>"; // !!! DEBUG !!!

    	// check return status of the executed command
    	if ( $return_var != 0 )	{
			$aresult[] = 'ERROR';
			if ( isset($command_output) ) {
			    $aresult[] = 'Command: <br>' . $bconsolecmd . '<br> output:<b>';
			} else {
			    $aresult[] = "Command: no output.<br />Check access to<br /><b>$bconsolecmd</b>";
			}
			foreach ($command_output as $line) {
				$aresult[] = $line;
			}
			$aresult[] = '</b>';
    		return $aresult;
    	}

    	// parsing Director output
        $begin1 = $begin2 = $begin3 = FALSE;
        $aresult = array();

        $i = 0;
        foreach ($command_output as $line) {
            $line = trim($line);
            // empty line
            if ( $line == '' )
                continue;
            // No scheduled tasks - out anyway
            if ( preg_match(self::NO_JOBS_RUNNING, $line) === 1 )  {
                $aresult = null;
                break;
            }
            // top of the list of scheduled tasks
            if ( (!$begin1) && (!$begin2) && (!$begin3) && ( preg_match(self::RUNNING_JOBS, $line) === 1) )  {
                $begin1 = TRUE;
                continue;
            }
            if ( $begin1 && (!$begin2) && (!$begin3) && ( preg_match('/^JobId /', $line) === 1) )  {
                $begin2 = TRUE;
                continue;
            }
            if ( $begin1 && $begin2 && (!$begin3) && ( preg_match(self::BEGIN_LIST, $line) === 1) )  {
                $begin3 = TRUE;
                continue;
            }
            // end of list
            if ( $begin1 && $begin2 && $begin3 && ( preg_match(self::END_LIST, $line) == 1) )
                break;

            // parse - separator - space
            // 0=JobId  1=Level  2=Name  3=Status
            if ( $begin1 && $begin2 && $begin3 )  {
                // парсим
                $acols = preg_split("/[\s]+/", $line, 4, PREG_SPLIT_NO_EMPTY);
                $count = count($acols);
                if ( $count == 4 ) {
                    $aresult[$i]['id']     = $acols[0];
                    $aresult[$i]['level']  = $acols[1];
                    $aresult[$i]['name']   = $acols[2];
                    $aresult[$i]['status'] = $acols[3];
                } else {
                    // incorrectly parse (changes in bacula?)
                    $aresult = null;
                    break;
                }
                $i++;
            }
        }
        // do Bacula ACLs
        return $this->bacula_acl->doBaculaAcl( $aresult, 'name', 'job');
    }




       /**
	 * Return % free space in VolumeName
	 *
	 * @param string $name
	 * @return -1 error, -100 new volume
	 */
	function getFreeVolumeCapacity($name)
	{
	    Zend_Loader::loadClass('Media');
	    $table = new Media();
	    $where  = $table->getAdapter()->quoteInto('VolumeName = ?', trim($name));
	    $row = $table->fetchRow($where);
            if ( !isset($row) )
	        return Zend_Registry::get('NEW_VOLUME');
	    else {
	       if ( $row->maxvolbytes != 0 )
	           return( floor(100 - ($row->volbytes * 100 / $row->maxvolbytes)) );
	       else
	           // tape storage may be maxvolbytes == 0
	           return Zend_Registry::get('UNKNOWN_VOLUME_CAPACITY');
	    }
	}


    /**
     * Scheduled Jobs (at 24 hours forward)
     *
     */
    function getScheduledJobs()
    {
    	$config = Zend_Registry::get('config');
    	// check access to bconsole
    	if ( !file_exists($config->general->bacula->bconsole))	{
    		$aresult[] = 'NOFOUND';
    		return $aresult;
    	}

    	$bconsolecmd = '';
        if ( isset($config->general->bacula->sudo))	{
            // run with sudo
            $bconsolecmd = $config->general->bacula->sudo . ' ' . $config->general->bacula->bconsole .
                    ' ' . $config->general->bacula->bconsolecmd;
        } else {
            $bconsolecmd = $config->general->bacula->bconsole . ' ' . $config->general->bacula->bconsolecmd;
        }

    	// run bconsole
    	$command_output = '';
    	$return_var = 0;
    	exec($bconsolecmd . ' <<EOF
status director
quit
EOF', $command_output, $return_var);

    	//echo "<pre>"; print_r($command_output); echo "</pre>"; // !!! DEBUG !!!

    	// check return status of the executed command
    	if ( $return_var != 0 )	{
			$aresult[] = 'ERROR';
			if ( isset($command_output) ) {
			    $aresult[] = 'Command: <br>' . $bconsolecmd . '<br> output:<b>';
			} else {
			    $aresult[] = "Command: no output.<br />Check access to<br /><b>$bconsolecmd</b>";
			}
			foreach ($command_output as $line) {
				$aresult[] = $line;
			}
			$aresult[] = '</b>';
    		return $aresult;
    	}

        // parse Director output
        $begin1 = $begin2 = $begin3 = FALSE;
        $aresult = array();

        $i = 0;
        foreach ($command_output as $line) {
            $line = trim($line);
            // empty line
            if ( $line == '' )
                continue;
            // No scheduled tasks - out anyway
            if ( preg_match(self::NO_SCHEDULED_JOBS, $line) === 1 )  {
                $aresult = null;
                break;
            }
            // top of the list of scheduled tasks
            if ( (!$begin1) && (!$begin2) && (!$begin3) && ( preg_match(self::SCHEDULED_JOBS, $line) === 1) )  {
                $begin1 = TRUE;
                continue;
            }
            if ( $begin1 && (!$begin2) && (!$begin3) && ( preg_match('/^Level /', $line) === 1) )  {
                $begin2 = TRUE;
                continue;
            }
            if ( $begin1 && $begin2 && (!$begin3) && ( preg_match(self::BEGIN_LIST, $line) === 1) )  {
                $begin3 = TRUE;
                continue;
            }
            // end of list
            if ( $begin1 && $begin2 && $begin3 && ( preg_match(self::END_LIST, $line) == 1) )
                break;

            // parse - separator - space
            // 0=Level    1=Type   2=Pri  3=Scheduled(date) 4=(time)   5=Name  6=Volume
            if ( $begin1 && $begin2 && $begin3 )  {
                // we try to parse
                $acols = preg_split("/[\s]+/", $line, -1, PREG_SPLIT_NO_EMPTY);
                $count = count($acols);
                $aresult[$i]['level'] = $acols[0][0];  // first letter F(ull), I(nc), D(iff)
                $aresult[$i]['type']  = $acols[1];
                $aresult[$i]['pri']   = $acols[2];
                $aresult[$i]['date']  = $acols[3] . ' ' . $acols[4];
                $aresult[$i]['vol']   = $acols[ $count-1 ];  // Volume in the name spaces can not be, so the last field - exactly Volume
                if ( $aresult[$i]['vol'] == '*unknown*')
                    $aresult[$i]['volfree'] = 'UNKNOWN_VOLUME_CAPACITY';
                else
                    $aresult[$i]['volfree'] = $this->getFreeVolumeCapacity($aresult[$i]['vol']);
                if ( $count == 7 ) {
                    // in the name of Job are no gaps
                    $aresult[$i]['name']  = $acols[5];
                } else {
                    // in the name of Job there are gaps (in the name of Volume gaps can not be)
                    $aresult[$i]['name']  = $acols[5];
                    for ($j = 6; $j <= $count-2; $j++) {
                        $aresult[$i]['name']  .= ' ' . $acols[$j];
                    }
                }
                $i++;
            }
        }
        // do Bacula ACLs
        $aresult_acl = array();
        $aresult_acl = $this->bacula_acl->doBaculaAcl( $aresult, 'name', 'job');
        // show short Job description
        $show_job_description = Zend_Registry::get('show_job_description');
        if ( $show_job_description > 0 )    {
            Zend_Loader::loadClass('Wbjobdesc');
            $wbjobdesc = new Wbjobdesc();
            foreach ($aresult_acl as &$line) {
                $where = $wbjobdesc->getAdapter()->quoteInto('name_job = ?', $line['name']);
                $row = $wbjobdesc->fetchRow($where);
                if ($row)   {
                    $line['short_desc'] = $row->short_desc;
                }
                unset($where, $row);
            }
            unset($line); /* to the next entry in the $ line did not change the last element of the array */
        }
        return $aresult_acl;
    }

    

    /**
     * Jobs with errors/problems (last NN days)
     *
     */
    function getProblemJobs($last_days)
    {
        $select = new Zend_Db_Select($this->db);
        $select->distinct();

        switch ($this->db_adapter) {
        case 'PDO_MYSQL':
            $select->from(array('j' => 'Job'),
               array('JobId', 'JobName' => 'Name', 'Level', 'ClientId', 'StartTime', 'EndTime',
                    'VolSessionId', 'VolSessionTime', 'JobFiles', 'JobBytes', 'JobErrors', 'Reviewed', 'PoolId',
                    'FileSetId', 'PurgedFiles', 'JobStatus', 'Type',
                    'DurationTime' => 'TIMEDIFF(EndTime, StartTime)'
            ));
            $select->joinLeft(array('s' => 'Status'), 'j.JobStatus = s.JobStatus', array('JobStatusLong'=>'JobStatusLong'));
            break;
        case 'PDO_PGSQL':
            // PostgreSQL
            $select->from(array('j' => 'Job'),
                array('JobId', 'JobName' => 'Name', 'Level', 'ClientId', 'StartTime', 'EndTime',
                    'VolSessionId', 'VolSessionTime', 'JobFiles', 'JobBytes', 'JobErrors', 'Reviewed', 'PoolId',
                    'FileSetId', 'PurgedFiles', 'JobStatus', 'Type',
                    'DurationTime' => '(EndTime - StartTime)'
            ));
            $select->joinLeft(array('s' => 'Status'), 'j.JobStatus = s.JobStatus', array('JobStatusLong'=>'JobStatusLong'));
            break;
        case 'PDO_SQLITE':
            // SQLite3 Documentation
            // http://sqlite.org/lang_datefunc.html
            // bug http://framework.zend.com/issues/browse/ZF-884
            // http://sqlite.org/pragma.html
            //$res = $db->query('PRAGMA short_column_names=1'); // not affected
            //$res = $db->query('PRAGMA full_column_names=0'); // not affected
            $select->from(array('j' => 'Job'),
                array('jobid' => 'JobId', 'JobName' => 'Name', 'level'=>'Level', 'clientid'=>'ClientId',
                    'starttime'=>'StartTime', 'endtime'=>'EndTime',
                    'volsessionid'=>'VolSessionId', 'volsessiontime'=>'VolSessionTime', 'jobfiles'=>'JobFiles',
                    'jobbytes'=>'JobBytes', 'joberrors'=>'JobErrors', 'reviewed'=>'Reviewed', 'poolid'=>'PoolId',
                    'filesetid'=>'FileSetId', 'purgedfiles'=>'PurgedFiles', 'jobstatus'=>'JobStatus',
                    'type' => 'Type',
                    'DurationTime' => "(strftime('%H:%M:%S',strftime('%s',EndTime) - strftime('%s',StartTime),'unixepoch'))"
            ));
            $select->joinLeft(array('s' => 'Status'), 'j.JobStatus = s.JobStatus', array('jobstatuslong'=>'JobStatusLong'));
            break;
        }
        $select->joinLeft(array('c' => 'Client'), 'j.ClientId = c.ClientId', array('ClientName' => 'Name'));
        $select->joinLeft(array('p' => 'Pool'),	'j.PoolId = p.PoolId', array('PoolName' => 'Name'));
        $select->joinLeft(array('f' => 'FileSet'), 'j.FileSetId = f.FileSetId', array('fileset'=>'FileSet'));
        $select->joinLeft(array('sd'=> 'webacula_jobdesc'), 'j.Name = sd.name_job');

        $last7day = date('Y-m-d H:i:s', time() - $last_days * 86400); // for compatibility
        $select->where("((j.JobErrors > 0) OR (j.JobStatus IN ('E','e','f','I','D')))");
        $select->where("j.EndTime > ?", $last7day);
        $select->where("j.Reviewed = 0");
        $select->order(array("StartTime", "JobId"));

        //$sql = $select->__toString(); echo "<pre>$sql</pre>"; exit; // for !!!debug!!!
        $stmt = $select->query();
        // do Bacula ACLs
        return $this->bacula_acl->doBaculaAcl( $stmt->fetchAll(), 'jobname', 'job');
    }


   /**
    * Get Listing All Jobs
    *
    */
    function getListJobs()
    {
      $director = new Director();
      // check access to bconsole
      if ( !$director->isFoundBconsole() )   {
         $aresult[] = 'ERROR: bconsole not found.';
         return $aresult;
          }
      $astatusdir = $director->execDirector(
"<<EOF
.jobs
@quit
EOF"
);
        // check return status of the executed command
        if ( $astatusdir['return_var'] != 0 )   {
         $aresult[] = 'ERROR';
         $aresult[] = 'bconsole output:<b>';
         foreach ($astatusdir['command_output'] as $line) {
            $aresult[] = $line;
         }
         $aresult[] = '</b>';
         return $aresult;
   }

      /* Parsing Director's output. */
      $aresult = array();
      foreach ($astatusdir['command_output'] as $line) {
            $line = trim($line);
            $pattern = "((^#|^Connecting|^1000 OK|^Enter a period|^use|^Automatically selected|^Using|^\.|quit|^You have messages))";
            if ( !preg_match($pattern, $line)) {
                $aresult[] = $line;
            }
            if($line=="quit"){
                break;
            }

   }
        sort($aresult);
        // do Bacula ACLs
        $res1dim = $this->bacula_acl->doBaculaAcl( $aresult, 'jobname', 'job');
      return $res1dim;
    }

    

	function getSelectFilteredJob($date_begin, $time_begin, $date_end, $time_end,
								$client, $fileset, $jlevel, $jstatus, $jtype, $volname,
								$orderp)
	{
		if ( isset($date_begin, $time_begin, $date_end, $time_end, $client, $fileset) )	{
   			$select = new Zend_Db_Select($this->db);

   			// !!! IMPORTANT !!! Zend_paginator not use DISTINCT somehow does not work in PDO_PGSQL
   			switch ($this->db_adapter) {
            case 'PDO_MYSQL':
            	//$select->distinct();
                $select->from(array('j' => 'Job'),
                    array('JobId', 'Type', 'JobName' => 'Name', 'Level', 'ClientId',
   				    'StartTime', 'EndTime',
   				    'VolSessionId', 'VolSessionTime', 'JobFiles', 'JobBytes', 'JobErrors', 'Reviewed', 'PoolId',
       			    'FileSetId', 'PurgedFiles', 'JobStatus',
       			    'DurationTime' => 'TIMEDIFF(EndTime, StartTime)'));
                break;
            case 'PDO_PGSQL':
                // PostgreSQL
                // http://www.postgresql.org/docs/8.0/static/functions-datetime.html
                $select->from(array('j' => 'Job'),
                    array('JobId', 'Type', 'JobName' => 'Name', 'Level', 'ClientId',
   				    'StartTime', 'EndTime',
   				    'VolSessionId', 'VolSessionTime', 'JobFiles', 'JobBytes', 'JobErrors', 'Reviewed', 'PoolId',
       			    'FileSetId', 'PurgedFiles', 'JobStatus',
       			    'DurationTime' => '(EndTime - StartTime)'));
                break;
			case 'PDO_SQLITE':
				// SQLite3 Documentation
				// http://sqlite.org/lang_datefunc.html
				$select->from(array('j' => 'Job'),
					array('JobId', 'Type', 'JobName' => 'Name', 'Level', 'ClientId',
					'StartTime', 'EndTime',
					'VolSessionId', 'VolSessionTime', 'JobFiles', 'JobBytes', 'JobErrors', 'Reviewed', 'PoolId',
					'FileSetId', 'PurgedFiles', 'JobStatus',
					'DurationTime' => "(strftime('%H:%M:%S',strftime('%s',EndTime) - strftime('%s',StartTime),'unixepoch'))"));
				break;
            }
   			$select->joinLeft(array('s' => 'Status'), 'j.JobStatus = s.JobStatus', array('JobStatusLong'));
   			$select->joinLeft(array('c' => 'Client'), 'j.ClientId = c.ClientId', array('ClientName' => 'c.Name'));
			$select->joinLeft(array('p' => 'Pool'),	'j.PoolId = p.PoolId', array('PoolName' => 'p.Name'));
			$select->joinLeft(array('f' => 'FileSet'), 'j.FileSetId = f.FileSetId', array('FileSet'));
                        $select->joinLeft(array('sd'=> 'webacula_jobdesc'), 'j.Name = sd.name_job');
                        $select->joinLeft(array('wjs'=> 'webacula_job_size'), 'j.JobId = wjs.JobId', array('FileSize' => 'FileSize'));
			$select->where( "('" . $date_begin . ' ' . $time_begin . "' <= j.StartTime) AND (j.StartTime <= '" .
				$date_end . ' ' . $time_end . "')" );

			if (  $fileset != "" )	{
				$select->where("f.FileSet='$fileset'"); // AND
			}
			// Full, Incremental, Differential
			if ( $jlevel != "")	{
				$select->where("j.Level='$jlevel'"); // AND
			}

			if ( $client != "" )	{
				$select->where("c.Name='$client'"); // AND
			}

			// JobStatus
			switch ($jstatus) {
			case "R":
				// Running
   				$select->where("j.JobStatus='$jstatus'");
   				break;
			case "T":
				// Terminated normally
   				$select->where("j.JobStatus='$jstatus'");
   				break;
    		case "t":
				// Terminated in Error
   				$select->where("j.JobStatus  IN ('E', 'e', 'f', 'I', 'D')");
   				break;
   			case "A":
				// Canceled by the user
   				$select->where("j.JobStatus='$jstatus'");
   				break;
   			case "W":
				// Waiting
   				$select->where("j.JobStatus IN ('F', 'S', 'm', 'M', 's', 'j', 'c', 'd', 't', 'p')");
   				break;
			}

			// Backup, Restore, Verify
			if ( $jtype != "")	{
				$select->where("j.Type='$jtype'"); // AND
			}

			if ( $orderp ) {
   		    	$order = array($orderp . ' ASC', 'JobId');
   			} else {
   		    	$order = array('JobId');
   			}

			$select->order($order);
            //$sql = $select->__toString(); echo "<pre>$sql</pre>"; exit; // !!!debug
            $stmt = $select->query();
            // do Bacula ACLs
            return $this->bacula_acl->doBaculaAcl( $stmt->fetchAll(), 'jobname', 'job');
   		}
	}



    /**
     * Search Job by JobId
     * @param integer $jobid
     * @return array of Jobs
     */
    function getByJobId($jobid)
    {
        if ( isset($jobid) )	{
        $select = new Zend_Db_Select($this->db);
        $select->distinct();

        switch ($this->db_adapter) {
            case 'PDO_MYSQL':
                $select->from(array('j' => 'Job'),
                    array('JobId', 'Type', 'JobName' => 'Name', 'Level', 'ClientId',
                    'StartTime', 'EndTime',
                    'StartTimeRaw' => 'j.StartTime',
                    'VolSessionId', 'VolSessionTime', 'JobFiles', 'JobBytes', 'JobErrors', 'Reviewed', 'PoolId',
                    'FileSetId', 'PurgedFiles', 'JobStatus',
                    'DurationTime' => 'TIMEDIFF(EndTime, StartTime)'));
                break;
            case 'PDO_PGSQL':
                // PostgreSQL
                // http://www.postgresql.org/docs/8.0/static/functions-datetime.html
                $select->from(array('j' => 'Job'),
                    array('JobId', 'Type', 'JobName' => 'Name', 'Level', 'ClientId',
                    'StartTime', 'EndTime',
                    'VolSessionId', 'VolSessionTime', 'JobFiles', 'JobBytes', 'JobErrors', 'Reviewed', 'PoolId',
                    'FileSetId', 'PurgedFiles', 'JobStatus',
                    'DurationTime' => '(EndTime - StartTime)'));
                break;
            case 'PDO_SQLITE':
                // SQLite3 Documentation
                // http://sqlite.org/lang_datefunc.html
                // workaround of bug http://framework.zend.com/issues/browse/ZF-884
                $select->from(array('j' => 'Job'),
                    array('jobid'=>'JobId', 'type'=>'Type', 'JobName' => 'Name', 'level'=>'Level', 'clientid'=>'ClientId',
                    'starttime'=>'StartTime', 'endtime'=>'EndTime',
                    'volsessionid'=>'VolSessionId', 'volsessiontime'=>'VolSessionTime', 'jobfiles'=>'JobFiles',
                    'jobbytes'=>'JobBytes', 'joberrors'=>'JobErrors', 'reviewed'=>'Reviewed', 'poolid'=>'PoolId',
                    'filesetid'=>'FileSetId', 'purgedfiles'=>'PurgedFiles', 'jobstatus'=>'JobStatus',
                    'DurationTime' => "(strftime('%H:%M:%S',strftime('%s',EndTime) - strftime('%s',StartTime),'unixepoch'))" ));
                break;
            }
            $select->joinLeft(array('s' => 'Status'), 'j.JobStatus = s.JobStatus', array('JobStatusLong'));
            $select->joinLeft(array('c' => 'Client'), 'j.ClientId = c.ClientId', array('ClientName' => 'Name'));
            $select->joinLeft(array('p' => 'Pool'),	'j.PoolId = p.PoolId', array('PoolName' => 'Name'));
            $select->joinLeft(array('f' => 'FileSet'), 'j.FileSetId = f.FileSetId', array('FileSet'));
            $select->joinLeft(array('sd'=> 'webacula_jobdesc'), 'j.Name = sd.name_job');
            $select->joinLeft(array('wjs'=> 'webacula_job_size'), 'j.JobId = wjs.JobId', array('FileSize' => 'FileSize'));
            $select->where("j.JobId = '$jobid'");
            $select->order(array("StartTime", "JobId"));
            //$sql = $select->__toString(); echo "<pre>$sql</pre>"; exit; // for !!!debug!!!
            $stmt = $select->query();
            // do Bacula ACLs
            return $this->bacula_acl->doBaculaAcl( $stmt->fetchAll(), 'jobname', 'job');
        }
    }



    /**
     * Search Job by Job Name
     * @param string $jobname
     * @return array of Jobs
     */
    function getByJobName($jobname)
    {
        if ( isset($jobname) )	{
        $select = new Zend_Db_Select($this->db);
        $select->distinct();

        switch ($this->db_adapter) {
            case 'PDO_MYSQL':
                $select->from(array('j' => 'Job'),
                    array('JobId', 'Type', 'JobName' => 'Name', 'Level', 'ClientId',
                    'StartTime', 'EndTime',
                    'StartTimeRaw' => 'j.StartTime',
                    'VolSessionId', 'VolSessionTime', 'JobFiles', 'JobBytes', 'JobErrors', 'Reviewed', 'PoolId',
                    'FileSetId', 'PurgedFiles', 'JobStatus',
                    'DurationTime' => 'TIMEDIFF(EndTime, StartTime)'));
                break;
            case 'PDO_PGSQL':
                // PostgreSQL
                // http://www.postgresql.org/docs/8.0/static/functions-datetime.html
                $select->from(array('j' => 'Job'),
                    array('JobId', 'Type', 'JobName' => 'Name', 'Level', 'ClientId',
                    'StartTime', 'EndTime',
                    'VolSessionId', 'VolSessionTime', 'JobFiles', 'JobBytes', 'JobErrors', 'Reviewed', 'PoolId',
                    'FileSetId', 'PurgedFiles', 'JobStatus',
                    'DurationTime' => '(EndTime - StartTime)'));
                break;
            case 'PDO_SQLITE':
                // SQLite3 Documentation
                // http://sqlite.org/lang_datefunc.html
                // workaround of bug http://framework.zend.com/issues/browse/ZF-884
                $select->from(array('j' => 'Job'),
                    array('jobid'=>'JobId', 'type'=>'Type', 'JobName' => 'Name', 'level'=>'Level', 'clientid'=>'ClientId',
                    'starttime'=>'StartTime', 'endtime'=>'EndTime',
                    'volsessionid'=>'VolSessionId', 'volsessiontime'=>'VolSessionTime', 'jobfiles'=>'JobFiles',
                    'jobbytes'=>'JobBytes', 'joberrors'=>'JobErrors', 'reviewed'=>'Reviewed', 'poolid'=>'PoolId',
                    'filesetid'=>'FileSetId', 'purgedfiles'=>'PurgedFiles', 'jobstatus'=>'JobStatus',
                    'DurationTime' => "(strftime('%H:%M:%S',strftime('%s',EndTime) - strftime('%s',StartTime),'unixepoch'))" ));
                break;
            }
            $select->joinLeft(array('s' => 'Status'), 'j.JobStatus = s.JobStatus', array('JobStatusLong'));
            $select->joinLeft(array('c' => 'Client'), 'j.ClientId = c.ClientId', array('ClientName' => 'Name'));
            $select->joinLeft(array('p' => 'Pool'),	'j.PoolId = p.PoolId', array('PoolName' => 'Name'));
            $select->joinLeft(array('f' => 'FileSet'), 'j.FileSetId = f.FileSetId', array('FileSet'));
            $select->joinLeft(array('sd'=> 'webacula_jobdesc'), 'j.Name = sd.name_job');
            $select->joinLeft(array('wjs'=> 'webacula_job_size'), 'j.JobId = wjs.JobId', array('FileSize' => 'FileSize'));
            $select->where("j.Name = '$jobname'");
            $select->order(array("StartTime desc", "JobId desc"));
            //$sql = $select->__toString(); echo "<pre>$sql</pre>"; exit; // for !!!debug!!!
            $stmt = $select->query();
            // do Bacula ACLs
            return $this->bacula_acl->doBaculaAcl( $stmt->fetchAll(), 'jobname', 'job');
        }
    }



	function getByVolumeName($volname)
	{
		if ( isset($volname) )	{
   			$select = new Zend_Db_Select($this->db);
   			$select->distinct();

   			switch ($this->db_adapter) {
            case 'PDO_MYSQL':
                $select->from(array('j' => 'Job'),
    			array('j.JobId', 'Type', 'JobName' => 'Name', 'Level', 'ClientId',
                    'StartTime', 'EndTime',
                    'VolSessionId', 'VolSessionTime', 'JobFiles', 'JobBytes', 'JobErrors', 'Reviewed', 'PoolId',
           			'FileSetId', 'PurgedFiles', 'JobStatus',
           			'DurationTime' => 'TIMEDIFF(EndTime, StartTime)' ));
    			$select->joinLeft(array('s' => 'Status'), 'j.JobStatus = s.JobStatus', array('JobStatusLong' => 'JobStatusLong'));
                break;
            case 'PDO_PGSQL':
            // PostgreSQL
            // http://www.postgresql.org/docs/8.0/static/functions-datetime.html
            	$select->from(array('j' => 'Job'),
					array('j.JobId', 'Type', 'JobName' => 'Name', 'Level', 'ClientId',
                    'StartTime', 'EndTime',
                    'VolSessionId', 'VolSessionTime', 'JobFiles', 'JobBytes', 'JobErrors', 'Reviewed', 'PoolId',
                    'FileSetId', 'PurgedFiles', 'JobStatus',
                    'DurationTime' => '(EndTime - StartTime)' ));
				$select->joinLeft(array('s' => 'Status'), 'j.JobStatus = s.JobStatus', array('JobStatusLong' => 'JobStatusLong'));
                break;
            case 'PDO_SQLITE':
				// workaround of bug http://framework.zend.com/issues/browse/ZF-884
				$select->from(array('j' => 'Job'),
					array('jobid'=>'JobId', 'job'=>'Job', 'JobName'=>'Name', 'level'=>'Level', 'clientid'=>'ClientId',
					'starttime'=>'StartTime', 'endtime'=>'EndTime', 'schedtime'=>'SchedTime',
					'volsessionid'=>'VolSessionId', 'volsessiontime'=>'VolSessionTime', 'jobfiles'=>'JobFiles',
					'jobbytes'=>'JobBytes', 'joberrors'=>'JobErrors', 'reviewed'=>'Reviewed', 'poolid'=>'PoolId',
					'filesetid'=>'FileSetId', 'purgedfiles'=>'PurgedFiles', 'jobstatus'=>'JobStatus', 'type'=>'Type',
					'DurationTime' => "(strftime('%H:%M:%S',strftime('%s',EndTime) - strftime('%s',StartTime),'unixepoch'))"
				));
				$select->joinLeft(array('s' => 'Status'), 'j.JobStatus = s.JobStatus', array('jobstatuslong' => 'JobStatusLong'));
				break;
            }
            $select->joinLeft(array('c' => 'Client'), 'j.ClientId = c.ClientId', array('ClientName' => 'Name'));
            $select->joinLeft(array('p' => 'Pool'),	'j.PoolId = p.PoolId', array('PoolName' => 'Name'));
            $select->joinLeft(array('f' => 'FileSet'), 'j.FileSetId = f.FileSetId');
            $select->joinLeft(array('o' => 'JobMedia'), 'j.JobId = o.JobId', array('JobId'));
            $select->joinLeft(array('m' => 'Media'), 'm.MediaId = o.MediaId', array('MediaId'));
            $select->joinLeft(array('sd'=> 'webacula_jobdesc'), 'j.Name = sd.name_job');
            $select->joinLeft(array('wjs'=> 'webacula_job_size'), 'j.JobId = wjs.JobId', array('FileSize' => 'FileSize'));

			$select->where("m.VolumeName = '$volname'");
   			$select->order(array("StartTime", "j.JobId"));
  			//$sql = $select->__toString(); echo "<pre>$sql</pre>"; exit; // for !!!debug!!!
   			$stmt = $select->query();
            // do Bacula ACLs
            return $this->bacula_acl->doBaculaAcl( $stmt->fetchAll(), 'jobname', 'job');
   		}
	}

    

	function getDetailByJobId($jobid)
	{
    	if ( $this->isJobIdExists($jobid) )	{
    		$select = new Zend_Db_Select($this->db);
    		$select->distinct();

    		switch ($this->db_adapter) {
            case 'PDO_MYSQL':
                $select->from(array('j' => 'Job'),
                    array('JobId', 'Job', 'Name', 'Level', 'ClientId',
                    'StartTime', 'EndTime', 'SchedTime',
    			    'VolSessionId', 'VolSessionTime', 'JobFiles', 'JobBytes', 'JobErrors', 'PoolId',
        		    'FileSetId', 'PurgedFiles', 'JobStatus', 'Type',
        		    'DurationTime' => 'TIMEDIFF(EndTime, StartTime)', 'PriorJobId',
                    'Reviewed', 'Comment'
                ));
                $select->joinLeft(array('s' => 'Status'), 'j.JobStatus = s.JobStatus', array('JobStatusLong' => 'JobStatusLong'));
                break;
            case 'PDO_PGSQL':
                // PostgreSQL
                // http://www.postgresql.org/docs/8.0/static/functions-datetime.html
                $select->from(array('j' => 'Job'),
                    array('JobId', 'Job', 'Name', 'Level', 'ClientId',
                    'StartTime', 'EndTime', 'SchedTime',
    			    'VolSessionId', 'VolSessionTime', 'JobFiles', 'JobBytes', 'JobErrors', 'PoolId',
        		    'FileSetId', 'PurgedFiles', 'JobStatus', 'Type',
        		    'DurationTime' => '(EndTime - StartTime)', 'PriorJobId',
                    'Reviewed', 'Comment'
    			));
    			$select->joinLeft(array('s' => 'Status'), 'j.JobStatus = s.JobStatus', array('JobStatusLong' => 'JobStatusLong'));
                break;
			case 'PDO_SQLITE':
				// SQLite3 Documentation
				// http://sqlite.org/lang_datefunc.html
				// bug http://framework.zend.com/issues/browse/ZF-884
				// http://sqlite.org/pragma.html
				//$res = $db->query('PRAGMA short_column_names=1'); // not affected
				//$res = $db->query('PRAGMA full_column_names=0'); // not affected
				$select->from(array('j' => 'Job'),
					array('jobid'=>'JobId', 'job'=>'Job', 'name'=>'Name', 'level'=>'Level', 'clientid'=>'ClientId',
					'starttime'=>'StartTime', 'endtime'=>'EndTime', 'schedtime'=>'SchedTime',
					'volsessionid'=>'VolSessionId', 'volsessiontime'=>'VolSessionTime', 'jobfiles'=>'JobFiles',
					'jobbytes'=>'JobBytes', 'joberrors'=>'JobErrors', 'poolid'=>'PoolId',
					'filesetid'=>'FileSetId', 'purgedfiles'=>'PurgedFiles', 'jobstatus'=>'JobStatus', 'type'=>'Type',
					'DurationTime' => "(strftime('%H:%M:%S',strftime('%s',EndTime) - strftime('%s',StartTime),'unixepoch'))",
                    'priorjobid'=>'PriorJobId', 'reviewed'=>'Reviewed', 'comment'=>'Comment'
				));
				$select->joinLeft(array('s' => 'Status'), 'j.JobStatus = s.JobStatus', array('jobstatuslong' => 'JobStatusLong'));
				break;
            }
            $select->joinLeft(array('c' => 'Client'), 'j.ClientId = c.ClientId',
                array('ClientName' => 'Name', 'ClientUName' => 'UName'));
            $select->joinLeft(array('p' => 'Pool'),	'j.PoolId = p.PoolId', array('PoolName' => 'Name'));
            $select->joinLeft(array('f' => 'FileSet'), 'j.FileSetId = f.FileSetId', 
                    array('FileSetName' => 'FileSet', 'FileSetCreateTime' => 'CreateTime'));
            $select->joinLeft(array('sd'=> 'webacula_jobdesc'), 'j.Name = sd.name_job');
            $select->joinLeft(array('wjs'=> 'webacula_job_size'), 'j.JobId = wjs.JobId', array('FileSize' => 'FileSize'));
        	$select->where("j.JobId = ?", $jobid);
    		//$sql = $select->__toString(); echo "<pre>$sql</pre>"; exit; // for !!!debug!!!

    		$stmt = $select->query();
			$aresult['job'] = $stmt->fetchAll();

			$select->reset();
			unset($select);
			unset($stmt);

			// list volumes
			$select = new Zend_Db_Select($this->db);
			switch ($this->db_adapter) {
			case 'PDO_SQLITE':
				// bug http://framework.zend.com/issues/browse/ZF-884
				$select->distinct();
    			$select->from(array('j' => 'JobMedia'),	array('mediaid'=>'MediaId'));
	    		$select->joinInner(array('m' => 'Media'), 'j.MediaId = m.MediaId', array('volumename'=>'VolumeName'));
        		$select->where("j.JobId = ?", $jobid);
				break;
			default: // mysql, postgresql
				$select->distinct();
    			$select->from(array('j' => 'JobMedia'),	array('MediaId'));
	    		$select->joinInner(array('m' => 'Media'), 'j.MediaId = m.MediaId', array('VolumeName'));
        		$select->where("j.JobId = ?", $jobid);
			}
        	//$sql = $select->__toString(); echo "<pre>$sql</pre>"; exit; // for !!!debug!!!

        	$stmt = $select->query();
			$aresult['volume'] = $stmt->fetchAll();

			$select->reset();
			unset($select);
			unset($stmt);
			return $aresult;
    	}
	}



	function getLastJobRun($numjob)
	{
		$select = new Zend_Db_Select($this->db);
		$select->distinct();
		$select->limit($numjob);

		switch ($this->db_adapter) {
            case 'PDO_MYSQL':
                $select->from(array('j' => 'Job'),
                    array('JobId', 'Type', 'JobName' => 'Name', 'Level', 'ClientId',
                    'sortStartTime' => 'StartTime',
			        'StartTime', 'EndTime',
			        'VolSessionId', 'VolSessionTime', 'JobFiles', 'JobBytes', 'JobErrors', 'Reviewed', 'PoolId',
   			         'FileSetId', 'PurgedFiles', 'JobStatus',
   			         'DurationTime' => 'TIMEDIFF(EndTime, StartTime)'
   		        ));
   		        $select->joinLeft(array('c' => 'Client'), 'j.ClientId = c.ClientId', array('ClientName' => 'Name'));
				$select->joinLeft(array('p' => 'Pool'),	'j.PoolId = p.PoolId',       array('PoolName' => 'Name'));
                $select->joinLeft(array('sd'=> 'webacula_jobdesc'), 'j.Name = sd.name_job');
				$select->joinInner(array('s' => 'Status'), "j.JobStatus = s.JobStatus" , array('JobStatusLong'));
            break;
        	case 'PDO_PGSQL':
            	// PostgreSQL
	            // http://www.postgresql.org/docs/8.0/static/functions-datetime.html
    	        $select->from(array('j' => 'Job'),
                    array('JobId', 'Type', 'JobName' => 'Name', 'Level', 'ClientId',
                    'sortStartTime' => 'StartTime',
			        'StartTime', 'EndTime',
			        'VolSessionId', 'VolSessionTime', 'JobFiles', 'JobBytes', 'JobErrors', 'Reviewed', 'PoolId',
   			         'FileSetId', 'PurgedFiles', 'JobStatus',
   			         'DurationTime' => '(EndTime - StartTime)'
   		        ));
   		        $select->joinLeft(array('c' => 'Client'), 'j.ClientId = c.ClientId', array('ClientName' => 'Name'));
				$select->joinLeft(array('p' => 'Pool'),	'j.PoolId = p.PoolId',       array('PoolName' => 'Name'));
                $select->joinLeft(array('sd'=> 'webacula_jobdesc'), 'j.Name = sd.name_job');
				$select->joinInner(array('s' => 'Status'), "j.JobStatus = s.JobStatus" , array('JobStatusLong'));
            break;
			case 'PDO_SQLITE':
				// SQLite3 Documentation
				// http://sqlite.org/lang_datefunc.html
				// bug http://framework.zend.com/issues/browse/ZF-884
				$select->from(array('j' => 'Job'),
					array('jobid'=>'JobId', 'type'=>'Type', 'JobName' => 'Name', 'level'=>'Level', 'clientid'=>'ClientId',
					'sortStartTime' => 'StartTime',
					'starttime'=>'StartTime', 'endtime'=>'EndTime',
					'volsessionid'=>'VolSessionId', 'volsessiontime'=>'VolSessionTime', 'jobfiles'=>'JobFiles',
					'jobbytes'=>'JobBytes', 'joberrors'=>'JobErrors', 'reviewed'=>'Reviewed', 'poolid'=>'PoolId',
					'filesetid'=>'FileSetId', 'purgedfiles'=>'PurgedFiles', 'jobstatus'=>'JobStatus',
					'DurationTime' => "(strftime('%H:%M:%S',strftime('%s',EndTime) - strftime('%s',StartTime),'unixepoch'))"
				));
				$select->joinLeft(array('c' => 'Client'), 'j.ClientId = c.ClientId', array('ClientName' => 'Name'));
				$select->joinLeft(array('p' => 'Pool'),	'j.PoolId = p.PoolId',       array('PoolName' => 'Name'));
                $select->joinLeft(array('sd'=> 'webacula_jobdesc'), 'j.Name = sd.name_job');
				$select->joinInner(array('s' => 'Status'), "j.JobStatus = s.JobStatus" , array('jobstatuslong'=>'JobStatusLong'));
			break;
        }
                $select->joinLeft(array('wjs'=> 'webacula_job_size'), 'j.JobId = wjs.JobId', array('FileSize' => 'FileSize'));
		$select->where("j.JobStatus IN ('T', 'E', 'e', 'f', 'A', 'W', 'D')");
		$select->where("j.Type = 'B'");
   		$select->order(array("sortStartTime DESC"));
   		//$sql = $select->__toString(); echo "<pre>$sql</pre>"; exit; // !!!debug
   		$stmt = $select->query();
        // do Bacula ACLs
        return $this->bacula_acl->doBaculaAcl( $stmt->fetchAll(), 'jobname', 'job');
    }


    /**
     * Make WHERE
     *
     * @param $field
     * @param $mask
     * @param $type_search      [ordinary | like | regexp]
     * @return SQL WHERE statement
     */
    function myMakeWhere($field, $mask, $type_search)
    {
        $mask = $this->db->quoteInto("?", $mask);
        switch ($type_search) {
        case 'like':
            switch ($this->db_adapter) {
                case 'PDO_MYSQL':
                    return "($field LIKE   $mask)";
                    break;
                case 'PDO_PGSQL':
                    return "($field LIKE   $mask)";
                    break;
                case 'PDO_SQLITE':
                    return "($field LIKE   $mask)";
                    break;
            }
            break;
        case 'regexp':
            switch ($this->db_adapter) {
                case 'PDO_MYSQL':
                    return "($field REGEXP $mask)";
                    break;
                case 'PDO_PGSQL':
                    return "($field ~ $mask)";
                    break;
                case 'PDO_SQLITE':
                    return "($field LIKE  $mask)"; //regexp not implemented by default
                    break;
            }
            break;
        default: // ordinary
            return "($field = $mask)";
            break;
        }
    }



    /**
     * Find File(s) by Path/Name file
     *
     * @param $path     with trailing slash
     * @param $namefile
     * @param $client
     * @param $limit
     * @param $type_search      [ordinary | like | regexp]
     * @return rows
     */
    function getByFileName($path, $namefile, $client, $limit, $type_search)
    {
        if ( isset($namefile, $client) )  {
            $select = new Zend_Db_Select($this->db);
            $select->distinct();
            $select->limit($limit);

            switch ($this->db_adapter) {
            case 'PDO_MYSQL':
                $select->from(array('j' => 'Job'),
                array('JobId', 'Type', 'JobName' => 'Name', 'Level', 'ClientId',
                    'StartTime' =>  'EndTime',
                    'VolSessionId', 'VolSessionTime', 'JobFiles', 'JobBytes', 'JobErrors', 'Reviewed', 'PoolId',
                    'FileSetId', 'PurgedFiles', 'JobStatus',
                    'DurationTime' => 'TIMEDIFF(EndTime, StartTime)'));
                $select->joinLeft('File', 'j.JobId = File.JobId', array('File.JobId', 'File.FileId'));
                $select->joinLeft('Filename', 'File.FilenameId = Filename.FilenameId', array('FileName' => 'Filename.Name'));
                $select->joinLeft('Path', 'File.PathId = Path.PathId', array('Path' => 'Path.Path'));
                $select->joinLeft('Status', 'j.JobStatus = Status.JobStatus', array('JobStatusLong' => 'Status.JobStatusLong'));
                $select->joinLeft('Client', 'j.ClientId = Client.ClientId',   array('ClientName' => 'Client.Name'));
                $select->joinLeft('Pool',	 'j.PoolId = Pool.PoolId',          array('PoolName' => 'Pool.Name'));
                $select->joinLeft('FileSet', 'j.FileSetId = FileSet.FileSetId', array('FileSet' => 'FileSet.FileSet'));
                $select->joinLeft(array('sd'=> 'webacula_jobdesc'), 'j.Name = sd.name_job');
                break;
            case 'PDO_PGSQL':
                // PostgreSQL
                // http://www.postgresql.org/docs/8.0/static/functions-datetime.html
                $select->from(array('j' => 'Job'),
                    array('JobId', 'Type', 'JobName' => 'Name', 'Level', 'ClientId',
                    'StartTime', 'EndTime',
                    'VolSessionId', 'VolSessionTime', 'JobFiles', 'JobBytes', 'JobErrors', 'Reviewed', 'PoolId',
                    'FileSetId', 'PurgedFiles', 'JobStatus',
                    'DurationTime' => '(EndTime - StartTime)'));
                $select->joinLeft('File', 'j.JobId = File.JobId', array('File.JobId', 'File.FileId'));
                $select->joinLeft('Filename', 'File.FilenameId = Filename.FilenameId', array('FileName' => 'Filename.Name'));
                $select->joinLeft('Path', 'File.PathId = Path.PathId', array('Path' => 'Path.Path'));
                $select->joinLeft('Status', 'j.JobStatus = Status.JobStatus', array('JobStatusLong' => 'Status.JobStatusLong'));
                $select->joinLeft('Client', 'j.ClientId = Client.ClientId',   array('ClientName' => 'Client.Name'));
                $select->joinLeft('Pool',	 'j.PoolId = Pool.PoolId',          array('PoolName' => 'Pool.Name'));
                $select->joinLeft('FileSet', 'j.FileSetId = FileSet.FileSetId', array('FileSet' => 'FileSet.FileSet'));
                $select->joinLeft(array('sd'=> 'webacula_jobdesc'), 'j.Name = sd.name_job');
                break;
            case 'PDO_SQLITE':
                // SQLite3 Documentation
                // http://sqlite.org/lang_datefunc.html
                // workaround of bug http://framework.zend.com/issues/browse/ZF-884
                $select->from(array('j' => 'Job'),
                array('jobid'=>'JobId', 'type'=>'Type', 'JobName' => 'Name', 'level'=>'Level', 'clientid'=>'ClientId',
                    'starttime'=>'StartTime', 'endtime'=>'EndTime',
                    'volsessionid'=>'VolSessionId', 'volsessiontime'=>'VolSessionTime', 'jobfiles'=>'JobFiles',
                    'jobbytes'=>'JobBytes', 'joberrors'=>'JobErrors', 'reviewed'=>'Reviewed', 'poolid'=>'PoolId',
                    'filesetid'=>'FileSetId', 'purgedfiles'=>'PurgedFiles', 'jobstatus'=>'JobStatus',
                    'DurationTime' => "(strftime('%H:%M:%S',strftime('%s',EndTime) - strftime('%s',StartTime),'unixepoch'))"));
                $select->joinLeft('File', 'j.JobId = File.JobId', array('File.JobId', 'File.FileId'));
                $select->joinLeft('Filename', 'File.FilenameId = Filename.FilenameId', array('FileName' => 'Filename.Name'));
                $select->joinLeft('Path', 'File.PathId = Path.PathId', array('path' => 'Path.Path'));
                $select->joinLeft('Status', 'j.JobStatus = Status.JobStatus', array('jobstatuslong' => 'Status.JobStatusLong'));
                $select->joinLeft('Client', 'j.ClientId = Client.ClientId',   array('clientname' => 'Client.Name'));
                $select->joinLeft('Pool',   'j.PoolId = Pool.PoolId',          array('poolname' => 'Pool.Name'));
                $select->joinLeft('FileSet', 'j.FileSetId = FileSet.FileSetId', array('fileset' => 'FileSet.FileSet'));
                $select->joinLeft(array('sd'=> 'webacula_jobdesc'), 'j.Name = sd.name_job');
                break;
            }
            // terminated jobs
            $select->where("j.JobStatus IN ('T', 'E', 'e', 'f', 'A', 'W')");

            if ( !empty($path) )    {
                $select->where(
                    $this->myMakeWhere('Path.Path', $path, $type_search));
            }

            $select->where(
                $this->myMakeWhere('Filename.Name', $namefile, $type_search));

            if ( !empty($client) )    {
                $select->where($this->db->quoteInto("Client.Name = ?", $client));
            }
            $select->order(array("StartTime DESC"));
            //$sql = $select->__toString(); echo "<pre>$sql</pre>"; exit; // for !!!debug!!!
        }
        $stmt = $select->query();
        // do Bacula ACLs
        return $this->bacula_acl->doBaculaAcl( $stmt->fetchAll(), 'jobname', 'job');
    }



    /**
     * with Bacula ACLs
     */
    function getJobBeforeDate($date_before, $client_id_from, $file_set)
    {
        /* Search Job Id last Full backup for the given Client, File Set, Date
         * cats/sql_cmds.c :: uar_last_full
         */
        $ajob_all = array();

        // level 'B' - Base job, see track ticket #90
        $sql =  "SELECT Job.JobId,Job.JobTDate,Job.ClientId, Job.Level,Job.JobFiles,Job.JobBytes," .
            " Job.StartTime, Media.VolumeName, JobMedia.StartFile, Job.VolSessionId,Job.VolSessionTime,
              Job.Name as jobname " .
            " FROM Client,Job,JobMedia,Media,FileSet
              WHERE Client.ClientId=$client_id_from" .
            " AND Job.ClientId=$client_id_from" .
            " $date_before".
            " AND Level IN ('F','B') AND JobStatus IN ('T','W') AND Type='B'" .
            " AND JobMedia.JobId=Job.JobId" .
            " AND Media.Enabled=1" .
            " AND JobMedia.MediaId=Media.MediaId" .
            " AND Job.FileSetId=FileSet.FileSetId" .
            " AND FileSet.FileSet='".$file_set."'" .
            " ORDER BY Job.JobTDate DESC" .
            " LIMIT 1";
        $stmt = $this->db->query($sql);
        // do Bacula ACLs
        $ajob_full = $this->bacula_acl->doBaculaAcl( $stmt->fetchAll(), 'jobname', 'job');
        unset($stmt);

        if ( empty($ajob_full) )
            return;

        $ajob_all[] = $ajob_full[0]['jobid'];
        /* Search fresh Differential backup after the Full backup, if there is
         * cats/sql_cmds.c :: uar_dif
         */
        $sql = "SELECT Job.JobId,Job.JobTDate,Job.ClientId, Job.Level,Job.JobFiles,Job.JobBytes," .
            " Job.StartTime, Media.VolumeName, JobMedia.StartFile, Job.VolSessionId,Job.VolSessionTime,
              Job.Name as jobname " .
            " FROM Job,JobMedia,Media,FileSet" .
            " WHERE Job.JobTDate>'".$ajob_full[0]['jobtdate']."'" .
            " $date_before" .
            " AND Job.ClientId=$client_id_from" .
            " AND JobMedia.JobId=Job.JobId" .
            " AND Media.Enabled=1" .
            " AND JobMedia.MediaId=Media.MediaId" .
            " AND Job.Level='D' AND JobStatus IN ('T','W') AND Type='B'" .
            " AND Job.FileSetId=FileSet.FileSetId" .
            " AND FileSet.FileSet='".$file_set."'" .
            " ORDER BY Job.JobTDate DESC" .
            " LIMIT 1";
        $stmt = $this->db->query($sql);
        $ajob_diff = $stmt->fetchAll();
        unset($stmt);

        if ( $ajob_diff ) {
            $ajob_all[] .= $ajob_diff[0]['jobid'];
        }
        /* Search fresh Incremental backups after the Full or Differential backups if there
         * cats/sql_cmds.c :: uar_inc
         */
        if ( !empty($ajob_diff[0]['jobtdate']) ) {
            $jobtdate = " AND Job.JobTDate>'" . $ajob_diff[0]['jobtdate'] . "'";
        } else {
            $jobtdate = " AND Job.JobTDate>'" . $ajob_full[0]['jobtdate'] . "'";
        }
        switch ($this->db_adapter) {
        case 'PDO_SQLITE':
            // bug http://framework.zend.com/issues/browse/ZF-884
            $sql = "SELECT DISTINCT Job.JobId as jobid, Job.JobTDate as jobtdate, Job.ClientId as clientid, " .
                " Job.Level as level, Job.JobFiles as jobfiles, Job.JobBytes as jobbytes, " .
                " Job.StartTime as starttime, Media.VolumeName as volumename, JobMedia.StartFile as startfile, " .
                " Job.VolSessionId as volsessionid, Job.VolSessionTime as volsessiontime, Job.Name as jobname " .
                " FROM Job,JobMedia,Media,FileSet" .
                " WHERE Media.Enabled=1 " .
                " $jobtdate " .
                " $date_before" .
                " AND Job.ClientId=$client_id_from" .
                " AND JobMedia.JobId=Job.JobId" .
                " AND JobMedia.MediaId=Media.MediaId" .
                " AND Job.Level='I' AND JobStatus IN ('T','W') AND Type='B'" .
                " AND Job.FileSetId=FileSet.FileSetId" .
                " AND FileSet.FileSet='".$file_set."'".
                " ORDER BY Job.StartTime ASC";
            break;
        default: // mysql, postgresql
            $sql = "SELECT DISTINCT Job.JobId,Job.JobTDate,Job.ClientId, Job.Level,Job.JobFiles,Job.JobBytes," .
                " Job.StartTime, Media.VolumeName ,JobMedia.StartFile, Job.VolSessionId, Job.VolSessionTime,
                  Job.Name as jobname " .
                " FROM Job,JobMedia,Media,FileSet" .
                " WHERE Media.Enabled=1 " .
                " $jobtdate " .
                " $date_before" .
                " AND Job.ClientId=$client_id_from" .
                " AND JobMedia.JobId=Job.JobId" .
                " AND JobMedia.MediaId=Media.MediaId" .
                " AND Job.Level='I' AND JobStatus IN ('T','W') AND Type='B'" .
                " AND Job.FileSetId=FileSet.FileSetId" .
                " AND FileSet.FileSet='".$file_set."'".
                " ORDER BY Job.StartTime ASC";
                break;
        }
        //echo "<pre>$sql</pre>"; exit; // for !!!debug!!!
        $stmt = $this->db->query($sql);
        $ajob_inc = $stmt->fetchAll();
        unset($stmt);

        // forming a hash of jobids
        if ( empty($ajob_diff) ) {
            $hash = '' . $ajob_full[0]['jobid'];
        } else {
            $hash = '' . $ajob_full[0]['jobid'] . $ajob_diff[0]['jobid'];
        }
        foreach ($ajob_inc as $line) {
            $hash = $hash . $line['jobid'];
            $ajob_all[] = $line['jobid'];
        }
        return(array('ajob_full' => $ajob_full, 'ajob_diff' => $ajob_diff, 'ajob_inc' => $ajob_inc,
            'ajob_all' => $ajob_all, 'hash' => $hash));
    }



    /**
     * Get records by FileId
     * @param $fileid
     * @return recordset
     */
    function getByFileId($fileid)
    {
        if ( empty($fileid) )
            return;
        $select = new Zend_Db_Select($this->db);
        $select->from(array('f' => 'File'), array('FileId', 'LStat'));
        $select->joinLeft(array('j' => 'Job'),  'j.JobId  = f.JobId',  array('JobId', 'jobname' => 'Name') );
        $select->joinLeft(array('p' => 'Path'), 'p.PathId = f.PathId', array('PathId', 'Path') );
        $select->joinLeft(array('n' => 'Filename'), 'n.FilenameId = f.FilenameId', array('Filename' => 'Name') );
        $select->where("f.FileId = ?", $fileid);
        //$sql = $select->__toString(); echo "<pre>$sql</pre>"; exit; // for !!!debug!!!
        $stmt = $select->query();
        // do Bacula ACLs
        //return $stmt->fetchAll();
        return $this->bacula_acl->doBaculaAcl( $stmt->fetchAll(), 'jobname', 'job');
    }



}
