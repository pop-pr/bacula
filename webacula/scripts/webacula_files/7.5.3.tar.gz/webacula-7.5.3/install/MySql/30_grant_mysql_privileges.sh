#!/bin/sh
#
# Script to grant privileges to the bacula database
#
echo "Execute the bacula script \"grant_mysql_privileges\"."
